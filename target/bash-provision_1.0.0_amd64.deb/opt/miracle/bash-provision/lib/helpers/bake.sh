bake () { eval "$*"; }
