satisfying () { [ "$operation" == "satisfy" ]; }
